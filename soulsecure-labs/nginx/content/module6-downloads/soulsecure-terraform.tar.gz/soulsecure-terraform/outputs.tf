output "bucket_name" {
  value = aws_s3_bucket.prod_assets.bucket
}

output "bastion_sg_id" {
  value = aws_security_group.bastion_sg.id
}
