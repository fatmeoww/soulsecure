resource "aws_security_group" "bastion_sg" {
  name        = "bastion-access"
  description = "Allow SSH access to the bastion host"

  tags = {
    flag = "flag{97f409cf01cab031eb48dbc42c86ec95}"
  }

  ingress {
    description = "SSH from anywhere"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
