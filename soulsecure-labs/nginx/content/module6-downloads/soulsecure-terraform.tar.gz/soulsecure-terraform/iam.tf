resource "aws_iam_policy" "legacy_broad" {
  name        = "LegacyBroadPolicy"
  description = "flag{c3ae4b3c35750c5b136829cceed7b10d}"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = "*"
        Resource = "*"
      }
    ]
  })
}

resource "aws_iam_user" "svc_legacy_app" {
  name = "svc-legacy-app"
}

resource "aws_iam_user_policy_attachment" "svc_legacy_attach" {
  user       = aws_iam_user.svc_legacy_app.name
  policy_arn = aws_iam_policy.legacy_broad.arn
}
