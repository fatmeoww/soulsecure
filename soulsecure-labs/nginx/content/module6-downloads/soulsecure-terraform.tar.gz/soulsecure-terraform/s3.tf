resource "aws_s3_bucket" "prod_assets" {
  bucket = "soulsecure-prod-assets"

  tags = {
    Environment = "production"
    flag        = "flag{12619665432a3c96437b87c7b96e896d}"
  }
}

resource "aws_s3_bucket_acl" "prod_assets_acl" {
  bucket = aws_s3_bucket.prod_assets.id
  acl    = "public-read"
}
