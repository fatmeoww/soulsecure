def add(a, b):
    return a + b

def slugify(s):
    return s.lower().replace(" ", "-")
