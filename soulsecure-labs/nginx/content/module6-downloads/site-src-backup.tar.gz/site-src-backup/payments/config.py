# payment gateway config
import os
STRIPE_WEBHOOK_TOLERANCE = 300
STRIPE_API_KEY = os.environ["STRIPE_API_KEY"]
